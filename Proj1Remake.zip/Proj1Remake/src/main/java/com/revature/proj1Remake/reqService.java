package com.revature.proj1Remake;

import java.util.List;

public class reqService {
	
	private ReqDaoImpl access=new ReqDaoImpl();
	public reqService() {
		super();// TODO Auto-generated constructor stub
	}
	
	public List<ReimbursementReq>getAll(){
		return access.getReimbursementReqs();
	}
	public ReimbursementReq getById(int id) {
		return access.getReimbursementReqById(id);
	}
	public int createReq(ReimbursementReq e)
	{
		return access.createReimbursementReq(e);
	}
	public void deleteReqById(int id)
	{
		access.deleteReimbursementReqById(id);
	}

}
