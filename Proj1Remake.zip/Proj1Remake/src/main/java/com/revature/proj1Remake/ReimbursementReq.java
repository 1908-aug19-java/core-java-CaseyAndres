package com.revature.proj1Remake;
//represents the request in the Reimbursement project.
public class ReimbursementReq {

	public ReimbursementReq() {
		super();
	}
	private String reason;	
	private boolean resolved;
	private boolean approved;
	private int resolverId;
	private int requestId;
	private int empReqId;
	private int amount;
	
	
	
	public ReimbursementReq(String reason, boolean resolved, boolean approved, int resolverId, int requestId,
			int empReqId, int amount) {
		super();
		this.reason = reason;
		this.resolved = resolved;
		this.approved = approved;
		this.resolverId = resolverId;
		this.requestId = requestId;
		this.empReqId = empReqId;
		this.amount = amount;
	}
	public ReimbursementReq(String reason, int amount) {
		super();
		this.reason = reason;
		this.amount = amount;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public boolean isResolved() {
		return resolved;
	}
	public void setResolved(boolean resolved) {
		this.resolved = resolved;
	}
	public boolean isApproved() {
		return approved;
	}
	public void setApproved(boolean approved) {
		this.approved = approved;
	}
	public int getResolverId() {
		return resolverId;
	}
	public void setResolverId(int resolverId) {
		this.resolverId = resolverId;
	}
	public int getRequestId() {
		return requestId;
	}
	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}
	public int getEmpReqId() {
		return empReqId;
	}
	public void setEmpReqId(int empReqId) {
		this.empReqId = empReqId;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	
}
