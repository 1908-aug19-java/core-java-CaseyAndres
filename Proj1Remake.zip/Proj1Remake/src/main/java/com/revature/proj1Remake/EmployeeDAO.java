package com.revature.proj1Remake;
import java.util.List;

public interface EmployeeDAO {
	public List<ReimbursementEmp> getReimbursementEmps();
	public List<ReimbursementEmp> getReimbursementEmpsAgain();
	public ReimbursementEmp getReimbursementEmpById(int id);
	public int createReimbursementEmp(ReimbursementEmp e);
	public int updateReimbursementEmp(ReimbursementEmp e);
	public int deleteReimbursementEmpById(int id);

}