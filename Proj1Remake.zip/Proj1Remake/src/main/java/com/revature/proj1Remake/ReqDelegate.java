package com.revature.proj1Remake;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.ObjectMapper;


public class ReqDelegate {
	
	private ReqDaoImpl ReimbursementEmpDao = new ReqDaoImpl();
	
	public void getReimbursementReqs(HttpServletRequest request, HttpServletResponse response) throws IOException{
		String idStr = request.getParameter("id");
		if(idStr == null) {
			List<ReimbursementReq> ReimbursementReqs = ReimbursementEmpDao.getReimbursementReqs();
			try(PrintWriter pw = response.getWriter();){
				pw.write(new ObjectMapper().writeValueAsString(ReimbursementReqs));
			}	
		} else {
			if(idStr.matches("^\\d+$")) {
				ReimbursementReq u = ReimbursementEmpDao.getReimbursementReqById(Integer.parseInt(idStr));
				if(u==null) {
					response.sendError(404, "No Employee with given ID");
				} else {
					try(PrintWriter pw = response.getWriter()){
						pw.write(new ObjectMapper().writeValueAsString(u));
					}
				}
			} else {
				response.sendError(400, "Invalid ID param");
			}
		}
	}
	public void postReimbursementReqs(HttpServletRequest request, HttpServletResponse response) throws IOException{
		String reason= request.getParameter("reason");	
		Integer amount = Integer.parseInt(request.getParameter("amount"));
		ReimbursementReq emp = new ReimbursementReq(reason, amount);
			ReimbursementEmpDao.createReimbursementReq(emp);
	}
	}
