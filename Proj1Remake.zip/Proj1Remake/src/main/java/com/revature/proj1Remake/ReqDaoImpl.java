package com.revature.proj1Remake;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ReqDaoImpl implements ReimbursementReqDAO {
//UserDAO implementation
	//TYPES OF requests
	// reason string
	//resolved boolean
	//approved boolean
	//resolverId int not null
	//requestId int primary key
	//empReqId int not null
	//amount int not null
	public ReqDaoImpl() {
	 super();	// TODO Auto-generated constructor stub
	}

	@Override
	public List<ReimbursementReq> getReimbursementReqs()  {
		
		List<ReimbursementReq> ReimbursementReqs = new ArrayList<>();
		String sql = "select * from requests";
		
		try(Connection c = ConnectionUtil.getConnection();
			Statement s = c.createStatement();
			ResultSet rs = s.executeQuery(sql)){
			
			while(rs.next()) {
				ReimbursementReq req=new ReimbursementReq();
				req.setReason(rs.getString("reason"));
				req.setResolved(rs.getBoolean("resolved"));
				req.setApproved(rs.getBoolean("approved"));
				req.setResolverId(rs.getInt("resolverid"));
				req.setRequestId(rs.getInt("requestid"));
				req.setEmpReqId(rs.getInt("empreqid"));
				req.setAmount(rs.getInt("amount"));
				ReimbursementReqs.add(req);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		

		
		return ReimbursementReqs;
	}

	@Override
	public List<ReimbursementReq> getReimbursementReqsAgain() {
		// TODO Auto-generated method stub
		return null;
	}
	//TYPES OF requests
		// reason string
		//resolved boolean
		//approved boolean
		//resolverId int not null
		//requestId int primary key
		//empReqId int not null
		//amount int not null
	@Override
	public ReimbursementReq getReimbursementReqById(int id)  {
		String sql = "select * from \"requests\" where \"requestId\" = ?";
		
	
		try(Connection c = ConnectionUtil.getConnection();
				PreparedStatement ps = c.prepareStatement(sql)){
			
			ps.setInt(1, id); // jdbc 1 based index
			ResultSet rs = ps.executeQuery();
			ReimbursementReq req = new ReimbursementReq();
			while(rs.next()) {
			req.setReason(rs.getString("reason"));
			req.setResolved(rs.getBoolean("resolved"));
			req.setApproved(rs.getBoolean("approved"));
			req.setResolverId(rs.getInt("resolverid"));
			req.setRequestId(rs.getInt("requestid"));
			req.setEmpReqId(rs.getInt("empreqid"));
			req.setAmount(rs.getInt("amount"));
				return req;
			
			}
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
	}

	public List<ReimbursementReq> getReqsByEmp(int id)  {
		String sql = "select * from \"requests\" where \"reqempid\" = ?";
		
	
		try(Connection c = ConnectionUtil.getConnection();
				PreparedStatement ps = c.prepareStatement(sql)){
			
			ps.setInt(1, id); // jdbc 1 based index
			ResultSet rs = ps.executeQuery();
			ReimbursementReq req = new ReimbursementReq();
			List<ReimbursementReq> ret = new ArrayList<ReimbursementReq>();
			while(rs.next()) {
			req.setReason(rs.getString("reason"));
			req.setResolved(rs.getBoolean("resolved"));
			req.setApproved(rs.getBoolean("approved"));
			req.setResolverId(rs.getInt("resolverid"));
			req.setRequestId(rs.getInt("requestid"));
			req.setEmpReqId(rs.getInt("empreqid"));
			req.setAmount(rs.getInt("amount"));
			ret.add(req);
			
			}
			rs.close();
			return ret;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}	
	
	//TYPES OF requests
			// reason string
			//resolved boolean
			//approved boolean
			//resolverId int not null
			//requestId int primary key
			//empReqId int not null
			//amount int not null
	
	@Override
	public int createReimbursementReq(ReimbursementReq e) {
		int UsersCreated = 0;
		String sql = "INSERT INTO \"requests\" (\"reason\", \"resolved\", approved, \"resolverid\", \"empreqid\", amount)" + "Values (?, ?, ?, ?, ?, ?)";
		//TODO correct statement
		try(Connection c = ConnectionUtil.getConnection();
				PreparedStatement ps = c.prepareStatement(sql)){
			ps.setString(1, e.getReason());
			ps.setBoolean(2, e.isResolved());
			ps.setBoolean(3, e.isApproved());
			ps.setInt(4, e.getResolverId());
			//ps.setInt(5, e.getRequestId());
			ps.setInt(5, e.getEmpReqId());
			ps.setInt(6, e.getAmount());


		
			UsersCreated = ps.executeUpdate();
			
		} catch (SQLException sqlerr) {
			sqlerr.printStackTrace();
		}
		
		return UsersCreated;
	}

	//TYPES OF requests
	// reason string
	//resolved boolean
	//approved boolean
	//resolverId int not null
	//requestId int primary key
	//empReqId int not null
	//amount int not null
	
	@Override
	public int updateReimbursementReq(ReimbursementReq e){
		int UsersUpdated = 0;
		String sql = "update \"requests\" "
				+ "set \"reason\" = ?, "
				+ "\"resolved\" = ?, "
				+ "\"approved\" = ?, "
				+ "\"resolverid\" = ?, "
				+ "\"requestid\" = ?, "
				+  "\"empreqid\" = ? "
				+  "\"amount\" = ? "
				+ "where \"requestid\" = ?";
		//TODO correct SQL Statement
		try(Connection c = ConnectionUtil.getConnection();
				PreparedStatement ps = c.prepareStatement(sql)){
			
//			ps.setInt(1, e.getUserId());
//			ps.setString(2, e.getUsername());
//			ps.setString(3, e.getPassword());
//			ps.setString(4, e.getEmail());
//			ps.setString(5, e.getRealName());
//			ps.setInt(6, e.getAccounts());
//			ps.setInt(7, e.getUserId());
			//TODO populate the statement
			
			UsersUpdated = ps.executeUpdate();
			
		} catch (SQLException sqlerr2) {
			sqlerr2.printStackTrace();
		}
		
		
		return UsersUpdated;
	}

	@Override
	public int deleteReimbursementReqById(int id) {
		int rowsDeleted = 0;
		String sql = "delete from \"requests\" where \"requestid\" = ?";
		//TODO correct SQL Statement
		try(Connection c = ConnectionUtil.getConnection();
				PreparedStatement ps = c.prepareStatement(sql)){
			
			ps.setInt(1, id);
			rowsDeleted = ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return rowsDeleted;
	}

	
	

}
