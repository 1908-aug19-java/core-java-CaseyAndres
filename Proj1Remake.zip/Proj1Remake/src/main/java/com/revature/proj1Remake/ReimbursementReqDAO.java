package com.revature.proj1Remake;
import java.util.List;

public interface ReimbursementReqDAO {
	public List<ReimbursementReq> getReimbursementReqs();
	public List<ReimbursementReq> getReimbursementReqsAgain();
	public ReimbursementReq getReimbursementReqById(int id);
	public int createReimbursementReq(ReimbursementReq e);
	public int updateReimbursementReq(ReimbursementReq e);
	public int deleteReimbursementReqById(int id);

}