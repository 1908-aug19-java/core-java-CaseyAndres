package com.revature.proj1Remake;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class RequestHelper {
	
	private ViewDelegate viewDelegate = new ViewDelegate();
	private ReqDelegate reqDelegate = new ReqDelegate();
	private EmpDelegate empDelegate = new EmpDelegate();
	private AuthDelegate authDelegate = new AuthDelegate();

	public void processGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		String path = request.getServletPath();
		System.out.println("In Process Get");
		System.out.println(path);
//		if(path.startsWith("/api/")) {
//			authDelegate.authenticate(request, response);
//			if(!authDelegate.isAuthorized(request)) {
//				System.out.println("Its the one in processGet");
//				response.sendError(401);
//				return;
//			}
			
			String record = path;
			System.out.println(record);
			switch(record) {
			case "/requests.html":
				reqDelegate.getReimbursementReqs(request, response);
				break;
			case "/employees.html":
				empDelegate.getReimbursementEmps(request, response);
				System.out.println("Its going to Employees");
				break;
			default:
				response.sendError(404, "Request Record(s) Not Found");
			}
			
		} 
		
	
	
	public void processPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		String path = request.getServletPath();
		System.out.println((path));
		switch(path) {
		case "/static/login.html":
			authDelegate.authenticate(request, response);
			break;
		case "/employees.html":
			System.out.println("you made it inside the right case");
			empDelegate.postReimbursementEmps(request, response);
			break;
		case "/static/requests.html":
			reqDelegate.postReimbursementReqs(request, response);
			break;
		default:
			System.out.println("its the one in procPost");
			response.sendError(405);
		}
	}
}