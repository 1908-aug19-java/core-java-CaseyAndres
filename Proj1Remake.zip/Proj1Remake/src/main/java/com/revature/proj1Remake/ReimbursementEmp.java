package com.revature.proj1Remake;
//Represents the Employee in the reimbursement project.
public class ReimbursementEmp {

	public ReimbursementEmp() {
		super();}
	private String realName;
	private String username;
	private String password;
	private int empId;
	private int mangId;
	
	public ReimbursementEmp(String realName, String username, String password, int empId, int mangId) {
		super();
		this.realName = realName;
		this.username = username;
		this.password = password;
		this.empId = empId;
		this.mangId = mangId;
	}
	public ReimbursementEmp(String realName, String username, String password, int empId) {
		super();
		this.realName = realName;
		this.username = username;
		this.password = password;
		this.empId = empId;
		this.mangId = -1;
	}
	//returns whether or not this employee is a manager or not using the default null value of -1 for mangId.
	//returns true if manager.
	public boolean isMang()
	{
		return this.mangId!=-1;
	}
	public String getRealName() {
		return realName;
	}
	public void setRealName(String realName) {
		this.realName = realName;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public int getMangId() {
		return mangId;
	}
	public void setMangId(int mangId) {
		this.mangId = mangId;
	}

}
