package com.revature.proj1Remake;

import java.util.List;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class ReqEmpDAOImpl implements EmployeeDAO {
//UserDAO implementation
//TYPES OF proj1emps table
	//empId int unique not null
	//mangId int
	//realName varchar(50) string
	//username varchar(50) string
	//password varchar 50 string

	public ReqEmpDAOImpl() {
	 super();	// TODO Auto-generated constructor stub
	}

	@Override
	public List<ReimbursementEmp> getReimbursementEmps()  {
		
		List<ReimbursementEmp> ReimbursementEmps = new ArrayList<>();
		String sql = "select * from proj1emps";
		
		try(Connection c = ConnectionUtil.getConnection();
			Statement s = c.createStatement();
			ResultSet rs = s.executeQuery(sql)){
			
			while(rs.next()) {
				ReimbursementEmp emp=new ReimbursementEmp();
				emp.setEmpId(rs.getInt("empid"));
				emp.setMangId(rs.getInt("mangid"));
				emp.setRealName(rs.getString("realname"));
				emp.setUsername(rs.getString("username"));
				emp.setPassword(rs.getString("password"));
				
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		

		
		return ReimbursementEmps;
	}

	@Override
	public List<ReimbursementEmp> getReimbursementEmpsAgain() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ReimbursementEmp getReimbursementEmpById(int id)  {
		String sql = "select * from \"proj1emps\" where \"empid\" = ?";

		try(Connection c = ConnectionUtil.getConnection();
				PreparedStatement ps = c.prepareStatement(sql)){
			
			ps.setInt(1, id); // jdbc 1 based index
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				ReimbursementEmp emp=new ReimbursementEmp();
				emp.setEmpId(rs.getInt("empid"));
				emp.setMangId(rs.getInt("mangid"));
				emp.setRealName(rs.getString("realname"));
				emp.setUsername(rs.getString("username"));
				emp.setPassword(rs.getString("password"));
				return emp;
			
			}
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
	}

	//TYPES OF proj1emps table
		//empId int unique not null
		//mangId int
		//realName varchar(50) string
		//username varchar(50) string
		//password varchar 50 string
	
	@Override
	public int createReimbursementEmp(ReimbursementEmp e) {
		int UsersCreated = 0;
		String sql = "INSERT INTO \"proj1emps\" (\"empid\", \"username\", password, \"realname\", \"mangid\")" + "Values (?, ?, ?, ?, ?)";
		//TODO correct statement
		try(Connection c = ConnectionUtil.getConnection();
				PreparedStatement ps = c.prepareStatement(sql)){
			ps.setInt(1, e.getEmpId());
			ps.setString(2, e.getUsername());
			ps.setString(3, e.getPassword());
			ps.setString(4, e.getRealName());
			ps.setInt(5,e.getMangId());

		
			UsersCreated = ps.executeUpdate();
			
		} catch (SQLException sqlerr) {
			sqlerr.printStackTrace();
		}
		
		return UsersCreated;
	}
	//TYPES OF proj1emps table
			//empId int unique not null
			//mangId int
			//realName varchar(50) string
			//username varchar(50) string
			//password varchar 50 string
		
	@Override
	public int updateReimbursementEmp(ReimbursementEmp e){
		int UsersUpdated = 0;
		String sql = "update \"proj1emps\" "
				+ "set \"empid\" = ?, "
				+ "\"mangid\" = ?, "
				+ "\"realname\" = ?, "
				+ "\"username\" = ?, "
				+ "\"password\" = ? "
				+ "where \"empid\" = ?";
		//TODO correct SQL Statement
		try(Connection c = ConnectionUtil.getConnection();
				PreparedStatement ps = c.prepareStatement(sql)){
			ps.setInt(1, e.getEmpId());
			ps.setInt(2, e.getMangId());
			ps.setString(3, e.getRealName());
			ps.setString(4, e.getUsername());
			ps.setString(5, e.getPassword());
			ps.setInt(6, e.getEmpId());
			UsersUpdated = ps.executeUpdate();
			
		} catch (SQLException sqlerr2) {
			sqlerr2.printStackTrace();
		}
		
		
		return UsersUpdated;
	}
    public ReimbursementEmp getUserByLogin(String username, String password)
    {
    	
    	String sql = "select * from \"proj1emps\" where \"username\" = ? and \"password\" = ?";
    	try(Connection c = ConnectionUtil.getConnection();
				PreparedStatement ps = c.prepareStatement(sql)){
			
			ps.setString(1, username); // jdbc 1 based index
			ps.setString(2, password);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				ReimbursementEmp emp=new ReimbursementEmp();
				emp.setEmpId(rs.getInt("empId"));
				emp.setMangId(rs.getInt("mangId"));
				emp.setRealName(rs.getString("realName"));
				emp.setUsername(rs.getString("username"));
				emp.setPassword(rs.getString("password"));
				return emp;			
			}
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
    	return null;
    }
	@Override
	public int deleteReimbursementEmpById(int id) {
		int rowsDeleted = 0;
		String sql = "delete from \"proj1emps\" where \"empId\" = ?";
		//TODO correct SQL Statement
		try(Connection c = ConnectionUtil.getConnection();
				PreparedStatement ps = c.prepareStatement(sql)){
			
			ps.setInt(1, id);
			rowsDeleted = ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return rowsDeleted;
	}

}