package com.revature.proj1Remake;

import java.util.List;

public class EmpService {

	public EmpService() {
		super();// TODO Auto-generated constructor stub
		emps = this.getAll();
	}
	ReqEmpDAOImpl access = new ReqEmpDAOImpl();
	private List<ReimbursementEmp> emps;
	public List<ReimbursementEmp> getAll()
	{
		return access.getReimbursementEmps();
	}
	public ReimbursementEmp getById(int id)
	{
		return access.getReimbursementEmpById(id);
	}
	public int createEmp(ReimbursementEmp e)
	{
		return access.createReimbursementEmp(e);
	}
	public int deleteEmp(int id)
	{
		return access.deleteReimbursementEmpById(id);
	}
}
