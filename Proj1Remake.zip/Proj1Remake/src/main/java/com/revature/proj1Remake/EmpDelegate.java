package com.revature.proj1Remake;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.ObjectMapper;


public class EmpDelegate {
	
	private ReqEmpDAOImpl ReimbursementEmpDao = new ReqEmpDAOImpl();
	
	public void getReimbursementEmps(HttpServletRequest request, HttpServletResponse response) throws IOException{
		String idStr = request.getHeader("id");
		System.out.println(idStr);
		if(idStr == null) {
			List<ReimbursementEmp> ReimbursementEmps = ReimbursementEmpDao.getReimbursementEmps();
			try(PrintWriter pw = response.getWriter();){
				pw.write(new ObjectMapper().writeValueAsString(ReimbursementEmps));
			}	
		} else {
			if(idStr.matches("^\\d+$")) {
				ReimbursementEmp u = ReimbursementEmpDao.getReimbursementEmpById(Integer.parseInt(idStr));
				if(u==null) {
					response.sendError(404, "No Employee with given ID");
				} else {
					try(PrintWriter pw = response.getWriter()){
						pw.write(new ObjectMapper().writeValueAsString(u));
					}
				}
			} else {
				response.sendError(400, "Invalid ID param");
			}
		}
	
	}
public void postReimbursementEmps(HttpServletRequest request, HttpServletResponse response) throws IOException{
	
	String realName = request.getHeader("newName");		
	String username = request.getHeader("newUsername");
	String password = request.getHeader("newPassword");
	Integer empId = Integer.parseInt(request.getHeader("userId"));
	Integer mangId = Integer.parseInt(request.getHeader("mangId"));
	ReimbursementEmp emp = new ReimbursementEmp(realName, username, password, empId, mangId);
	System.out.println(emp.toString());
	if(ReimbursementEmpDao.getReimbursementEmpById(empId)!=null) {
		System.out.println("You made it to update");
		ReimbursementEmpDao.updateReimbursementEmp(emp);
	}
	else
		ReimbursementEmpDao.createReimbursementEmp(emp);
}

}