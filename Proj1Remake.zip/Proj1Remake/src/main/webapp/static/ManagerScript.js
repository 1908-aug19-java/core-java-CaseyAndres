let token = sessionStorage.getItem("token");
//console.log(token);

if(!token){
	window.location.href="http://localhost:8080/Proj1Remake/login";
} else {
	let tokenArr = token.split(":");
	console.log(tokenArr);
	if(tokenArr.length===2){
		let baseUrl = "http://localhost:8080/Proj1Remake/api/users?id=";
		sendAjaxGet(baseUrl+tokenArr[0], displayName);
	} else {
		window.location.href="http://localhost:8080/Proj1Remake/login";
	}
}

/*
 * if we are not redirected when checking for the token, a request will be made to 
 * the url for that particular user 
 */

function sendAjaxGet(url, callback){
	let xhr = new XMLHttpRequest();
	xhr.open("GET", url);
	xhr.onreadystatechange = function(){
		if(this.readyState===4 && this.status===200){
			callback(this);
		} else if (this.readyState===4){
			window.location.href="http://localhost:8080/Proj1Remake/login";
		}
	}
	xhr.setRequestHeader("Authorization",token);
	xhr.send();
}

function displayRequests(){
	let url = "http://localhost:8080/Proj1Remake/static/requests.html"
		let xhr = new XMLHttpRequest();
	xhr.open("GET", url);
	xhr.onreadystatechange = function(){
		if(this.readyState === 4 && this.status===200){
			// set authorization in our browser for future request
			let auth = xhr.getResponseHeader("Authorization");
			sessionStorage.setItem("token", auth);
			console.log(auth);
		}
		if(this.readyState === 4 ){
			console.log(this);
		}
	}
	
	
	xhr.send();
}
function displayEmployees(){
	let url = "http://localhost:8080/Proj1Remake/static/employees.html"
		let xhr = new XMLHttpRequest();
	xhr.open("GET", url);
	xhr.onreadystatechange = function(){
		if(this.readyState === 4 && this.status===200){
			// set authorization in our browser for future request
			let auth = xhr.getResponseHeader("Authorization");
			sessionStorage.setItem("token", auth);
			console.log(auth);
		}
		if(this.readyState === 4 ){
			console.log(this);
		}
	}
	
	
	xhr.send();
	
}
function displaySpecificEmployee(){
	let url = "http://localhost:8080/Proj1Remake/static/employees.html"
		let xhr = new XMLHttpRequest();
	xhr.open("GET", url);
	xhr.onreadystatechange = function(){
		if(this.readyState === 4 && this.status===200){
			// set authorization in our browser for future request
			let auth = xhr.getResponseHeader("Authorization");
			sessionStorage.setItem("token", auth);
			console.log(auth);
		}
		if(this.readyState === 4 ){
			console.log(this);
		}
	}
	let userId= document.getElementById("Employee ID").value;
	xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");	
	let requestBody = `id=${userId}`;
	
	xhr.send(requestBody);
	
}
function approveReq()
{
	
}
function displaySpecRequest()
{
	let url = "http://localhost:8080/Proj1Remake/static/requests.html"
		let xhr = new XMLHttpRequest();
	xhr.open("GET", url);
	xhr.onreadystatechange = function(){
		if(this.readyState === 4 && this.status===200){
			// set authorization in our browser for future request
			let auth = xhr.getResponseHeader("Authorization");
			sessionStorage.setItem("token", auth);
			console.log(auth);
		}
		if(this.readyState === 4 ){
			console.log(this);
		}
	}
	let userId = document.getElementById("Request Id").value;
	xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");	
	let requestBody = `id=${userId}`;
	
	xhr.send(requestBody);
}