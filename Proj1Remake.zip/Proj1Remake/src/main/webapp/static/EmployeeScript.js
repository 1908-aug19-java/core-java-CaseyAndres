let token = sessionStorage.getItem("token");

//console.log(token);



/*
 * if we are not redirected when checking for the token, a request will be made to 
 * the url for that particular user 
 */

function sendAjaxGet(url, callback){
	let xhr = new XMLHttpRequest();
	xhr.open("GET", url);
	xhr.onreadystatechange = function(){
		if(this.readyState===4 && this.status===200){
			callback(this);
		} else if (this.readyState===4){
			window.location.href="http://localhost:8080/Proj1Remake/login";
		}
	}
	xhr.setRequestHeader("Authorization",token);
	xhr.send();
}

function sendReimbursementReq(){
	let url = "http://localhost:8080/Proj1Remake/static/requests.html"
		let xhr = new XMLHttpRequest();
	xhr.open("POST", url);
	xhr.onreadystatechange = function(){
		if(this.readyState === 4 && this.status===200){
			// set authorization in our browser for future request
			let auth = xhr.getResponseHeader("Authorization");
			sessionStorage.setItem("token", auth);
			console.log(auth);
		}
		if(this.readyState === 4 ){
			console.log(this);
		}
	}
	let reason = document.getElementById("reason").value;
	let amount = document.getElementById("Amount ID").value;
	xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");	
	let requestBody = `reason=${reason}&amount=${amount}`;
	
	xhr.send(requestBody);
}

function viewRequests(){
	let url = "http://localhost:8080/Proj1Remake/requests.html"
		let xhr = new XMLHttpRequest();
	document.getElementById("output").innerHTML = "Hello from viewRequests";
	xhr.open("GET", url);
	xhr.onreadystatechange = function(){
		if(this.readyState === 4 && this.status===200){
			// set authorization in our browser for future request
			let auth = xhr.getResponseHeader("Authorization");
			sessionStorage.setItem("token", auth);
			console.log(auth);
			document.getElementById("output").innerHTML =xhr.response ||"Output";
		}
		if(this.readyState === 4 ){
			console.log(this);
		}
	}
	let tokenArr = token.split(":");
	let userId=tokenArr[0];
	xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");	
	let requestBody = `id=${userId}`;
	
	xhr.send(requestBody);
	
}
function viewProfile(){
	let url = "http://localhost:8080/Proj1Remake/employees.html"
		let xhr = new XMLHttpRequest();
	console.log("YOUVE GOTTEN IN");
	document.getElementById("output").innerHTML = "Hello from viewRequests";
	xhr.open("GET", url);
	xhr.onreadystatechange = function(){
		if(this.readyState === 4 && this.status===200){
			// set authorization in our browser for future request
			let auth = xhr.getResponseHeader("Authorization");
			sessionStorage.setItem("token", auth);
			console.log(auth);
			document.getElementById("output").innerHTML =xhr.response ||"Output";
		}
		if(this.readyState === 4 ){
			console.log(this);
		}
	}
	let tokenArr = token.split(":");
	let userId=tokenArr[0];
	xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");	
	let requestBody = `id=${userId}`;
	console.log(requestBody);
	xhr.setRequestHeader("id", userId);
	xhr.send(requestBody);
	
}
function updateProfile(){
	let url = "http://localhost:8080/Proj1Remake/employees.html"
		let xhr = new XMLHttpRequest();
	xhr.open("POST", url);
	xhr.onreadystatechange = function(){
		if(this.readyState === 4 && this.status===200){
			// set authorization in our browser for future request
			let auth = xhr.getResponseHeader("Authorization");
			sessionStorage.setItem("token", auth);
			console.log(auth);
		}
		if(this.readyState === 4 ){
			console.log(this);
		}
	}
	let newName = document.getElementById("newName").value;
	let newPass = document.getElementById("newPass").value;
	let tokenArr = token.split(":");
	let userId=tokenArr[0];
	console.log(userId);
	let mangId = tokenArr[1];
	let newUsername = document.getElementById("newusername").value;
	xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	xhr.setRequestHeader("newName", newName);
	xhr.setRequestHeader("newPass", newPass);
	xhr.setRequestHeader("newUsername", newUsername);
	xhr.setRequestHeader("userId", userId);
	xhr.setRequestHeader("mangId", mangId);
	let requestBody = `newName=${reason}&newPass=${newPass}&newusername=${newUsername}`;
	
	xhr.send(requestBody);
	
}