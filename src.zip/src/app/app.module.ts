import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { Prob1Component } from './probs/prob1/prob1.component';
import { Prob2Component } from './probs/prob2/prob2.component';
import { Prob3Component } from './probs/prob3/prob3.component';
import { Prob4Component } from './probs/prob4/prob4.component';
import { Prob5Component } from './probs/prob5/prob5.component';
import { Prob6Component } from './probs/prob6/prob6.component';

@NgModule({
  declarations: [
    AppComponent,
    Prob1Component,
    Prob2Component,
    Prob3Component,
    Prob4Component,
    Prob5Component,
    Prob6Component
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
