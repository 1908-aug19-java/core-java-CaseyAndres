import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Prob4Component } from './prob4.component';

describe('Prob4Component', () => {
  let component: Prob4Component;
  let fixture: ComponentFixture<Prob4Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Prob4Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Prob4Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
