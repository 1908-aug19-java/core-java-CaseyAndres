import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prob4',
  templateUrl: './prob4.component.html',
  styleUrls: ['./prob4.component.css']
})
export class Prob4Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
