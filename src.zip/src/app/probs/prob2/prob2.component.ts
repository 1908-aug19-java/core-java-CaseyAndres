import {Component} from '@angular/core';
import { HighlightDelayBarrier } from 'blocking-proxy/built/lib/highlight_delay_barrier';

/**
 * @title Radios with ngModel
 */
@Component({
  selector: 'app-prob2',
  templateUrl: './prob2.component.html',
  styleUrls: ['./prob2.component.css']
})
export class Prob2Component {
  favoriteSeason: string;
  username: string = "test";
  name: string = "test";
  hidden: boolean = true;
}
function hide()
{
  if(this.hidden)
  this.hidden=false;
  else
  this.hidden=true;
}