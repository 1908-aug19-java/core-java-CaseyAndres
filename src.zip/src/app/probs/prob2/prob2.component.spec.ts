import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Prob2Component } from './prob2.component';

describe('Prob2Component', () => {
  let component: Prob2Component;
  let fixture: ComponentFixture<Prob2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Prob2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Prob2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
