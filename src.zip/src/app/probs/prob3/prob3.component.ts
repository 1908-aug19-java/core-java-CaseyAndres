import {Component} from '@angular/core';

/**
 * @title Radios with ngModel
 */
@Component({
  selector: 'app-prob3',
  templateUrl: './prob3.component.html',
  styleUrls: ['./prob3.component.css']
})
export class Prob3Component {
  favoriteSeason: string;
  seasons: string[] = ['animals', 'colors', 'days'];
}