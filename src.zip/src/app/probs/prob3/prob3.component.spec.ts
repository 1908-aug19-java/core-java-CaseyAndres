import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Prob3Component } from './prob3.component';

describe('Prob3Component', () => {
  let component: Prob3Component;
  let fixture: ComponentFixture<Prob3Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Prob3Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Prob3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
