import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prob5',
  templateUrl: './prob5.component.html',
  styleUrls: ['./prob5.component.css']
})
export class Prob5Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
