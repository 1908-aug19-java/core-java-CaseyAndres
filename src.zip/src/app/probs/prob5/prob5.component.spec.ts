import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Prob5Component } from './prob5.component';

describe('Prob5Component', () => {
  let component: Prob5Component;
  let fixture: ComponentFixture<Prob5Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Prob5Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Prob5Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
