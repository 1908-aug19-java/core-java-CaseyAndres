import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prob6',
  templateUrl: './prob6.component.html',
  styleUrls: ['./prob6.component.css']
})
export class Prob6Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
