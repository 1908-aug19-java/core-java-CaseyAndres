import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Prob1Component } from './prob1.component'; 

describe('Prob1Component', () => {
  let component: Prob1Component;
  let fixture: ComponentFixture<Prob1Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Prob1Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Prob1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
