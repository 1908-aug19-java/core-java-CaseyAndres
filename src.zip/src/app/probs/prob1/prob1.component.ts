import { Component, OnInit } from '@angular/core';
import { NgStyle } from '@angular/common';

@Component({
  selector: 'app-prob1',
  templateUrl: './prob1.component.html',
  styleUrls: ['./prob1.component.css']
})
export class Prob1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }
 
}
